
from difflib import SequenceMatcher
from .models import ArrivalItem, MasterItem


class Matcher:
    """Matches normalized arrival items against MASTER."""

    def __init__(self, master_items: list[MasterItem]):
        self.master_items = master_items
        self.index = {item.normalized_key: item for item in master_items}

    def _score(self, arrival: ArrivalItem, master: MasterItem) -> int:
        score = 0
        if arrival.brand and arrival.brand == master.brand:
            score += 100
        if arrival.category and arrival.category == master.category:
            score += 60
        if arrival.volume and arrival.volume.upper() == master.volume.upper():
            score += 100
        ratio = SequenceMatcher(
            None,
            (arrival.variant or "").upper(),
            (master.variant or "").upper()
        ).ratio()
        score += int(ratio * 200)
        return score

    def match(self, item: ArrivalItem) -> ArrivalItem:
        master = self.index.get(item.normalized_key)
        if master is None:
            candidates = [
                m for m in self.master_items
                if (not item.brand or m.brand == item.brand)
                and (not item.volume or m.volume.upper()==item.volume.upper())
            ]
            best=None
            best_score=-1
            for c in candidates:
                s=self._score(item,c)
                if s>best_score:
                    best_score=s
                    best=c
            if best and best_score>=220:
                master=best
        if master is None:
            item.status="REVIEW"
            return item
        item.sku=master.sku
        item.master_name=f"{master.category} {master.brand} {master.variant} {master.volume}"
        item.status="MATCH"
        return item

    def match_all(self, items:list[ArrivalItem])->list[ArrivalItem]:
        return [self.match(i) for i in items]
